import React from 'react'

function Student(){
    return (
        <div>
            <div>George</div>
            <div>CSE</div>
       </div>
    )
}
export default Student